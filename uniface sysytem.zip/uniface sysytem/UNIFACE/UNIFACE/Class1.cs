﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UNIFACE
{
    class Class1
    {
        static string Username;
        public static string username
        {
            get
            {
                return Username;
            }
            set
            {
                Username = value;
            }
        }
    }
}
