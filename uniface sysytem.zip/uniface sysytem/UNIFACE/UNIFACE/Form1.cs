﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;
using FireSharp;
using Newtonsoft.Json;

namespace UNIFACE
{
    public partial class Form1 : Form
    {
        // Variables to store user information
        private string name;
        private string subject_name;
        private string subject_code;
        private string email;
        private string username;


        // Constructor to initialize the form with user information
        public Form1(string name, string subject_name, string subject_code, string username, string email)
        {
            InitializeComponent();
            this.name = name;
            this.subject_name = subject_name;
            this.subject_code = subject_code;
            this.email = email;
            this.username = username;

            label10.Text = "Welcome, " + name;
            label16.Text = subject_name;
            label17.Text = subject_code;
        
        }

        public Form1()
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        // Event handler for logout button click
        private void label9_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Form2 form2 = new Form2();
                form2.Show();
                this.Hide();
            }
            
        }

        // Firebase configuration settings
        IFirebaseConfig ifc = new FirebaseConfig()
        {
            AuthSecret = "18QO5ufBMP8Ue4KRDhlhvWsUNqyEqrvHNuVrLNlp",
            BasePath = "https://unifaceattendance-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private void Form1_Load(object sender, EventArgs e)
        {
            try {
                client = new FirebaseClient(ifc);
            }
            catch (Exception){
                MessageBox.Show("There was a some problem in your internet");
            }
        }

        // Event handler for button click to fetch live data
        private void button1_Click(object sender, EventArgs e)
        {
            string studentId = textBox2.Text;

            // Check if the student ID is a valid integer
            if (int.TryParse(studentId, out _))
            {
                LiveCall(studentId);
            }
            else
            {
                MessageBox.Show("Please enter a valid student ID.");
            }
        }

        // Asynchronous method to fetch live data from Firebase
        async Task LiveCall(string studentId)
        {
            while (true)
            {
                // Get student data from Firebase
                FirebaseResponse res = await client.GetAsync($"Students/{studentId}");

                // Check if the student ID exists in the database
                if (res.Body != "null")
                {
                    Dictionary<string, string> data = JsonConvert.DeserializeObject<Dictionary<string, string>>(res.Body.ToString());
                    UpdateRTB(data);
                }
                else
                {
                    MessageBox.Show("Please enter a valid student ID.");
                    break; // Stop the loop if the student ID is invalid
                }
            }
        }

   
        // Method to update the RichTextBox with student data
        void UpdateRTB(Dictionary<string, string> record)
        {
            richTextBox1.Text = "";
            richTextBox1.Text += record.ElementAt(0).Key + "--" + record.ElementAt(0).Value + "\n\n";
            richTextBox1.Text += record.ElementAt(1).Key + "--" + record.ElementAt(1).Value + "\n\n";
            richTextBox1.Text += record.ElementAt(2).Key + "--" + record.ElementAt(2).Value + "\n\n";
            richTextBox1.Text += record.ElementAt(3).Key + "--" + record.ElementAt(3).Value + "\n\n";
            richTextBox1.Text += record.ElementAt(4).Key + "--" + record.ElementAt(4).Value + "\n\n";
            richTextBox1.Text += record.ElementAt(5).Key + "--" + record.ElementAt(5).Value + "\n\n";
            richTextBox1.Text += record.ElementAt(6).Key + "--" + record.ElementAt(6).Value + "\n\n";

            /*string value = record.ElementAt(5).Value;
            label18.Text = value;
            int days = 30;
            String Precentage;


            Precentage = (value/ days) * 100;*/

            string strValue = record.ElementAt(5).Value;
            double numericValue;
            if (double.TryParse(strValue, out numericValue))
            {
                // Calculate the percentage
                int days = 30;
                double percentage = (numericValue / days) * 100;

                // Format the percentage value to a string with two decimal places
                string formattedPercentage = percentage.ToString("F2");

                // Set the label's text to the formatted percentage
                label18.Text = formattedPercentage + "%";
            }
            else
            {
                // Handle invalid input or conversion error
                MessageBox.Show("Invalid data format for attendance value.");
            }

        }
        //label18.Text += record.ElementAt(5).Key + "--" + record.ElementAt(6).Value + "\n\n";

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string studentId;

            // Save data from the TextBox to the variable
            studentId = textBox2.Text;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
           
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        // Event handler for clicking on a label to open Form3 and hide the current form
        private void label7_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(email,name,subject_code,subject_name,username);
            form3.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        // Event handler for clicking on a label to open Form2 and hide the current form
        private void pictureBox11_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void label18_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }
    }
}
