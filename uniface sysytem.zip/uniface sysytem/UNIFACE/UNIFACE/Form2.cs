﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace UNIFACE
{
    public partial class Form2 : Form
    {
        // SQL connection string
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-M0HGLG4\SQLEXPRESS;Initial Catalog=uniface;Integrated Security=True");
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {


        }

        // Event handler for login button click
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                MessageBox.Show("Enter username and password");
            }
            else if (textBox1.Text == "")
            {
                MessageBox.Show("Enter the username");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Enter the password");
            }
            else
            {

                // SQL command to check login credentials
                SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-M0HGLG4\SQLEXPRESS;Initial Catalog=uniface;Integrated Security=True");
                SqlCommand sqlCommand = new SqlCommand("select * from login where username = @username and password= @password ", sqlConnection);
                sqlCommand.Parameters.AddWithValue("@username", textBox1.Text);
                sqlCommand.Parameters.AddWithValue("@password", textBox2.Text);

                // Use DataAdapter to fill DataTable with results
                SqlDataAdapter sqlData = new SqlDataAdapter(sqlCommand);
                DataTable data = new DataTable();
                sqlData.Fill(data);

                // If login is successful, retrieve user information and open Form1
                if (data.Rows.Count > 0)
                {
                    string name = data.Rows[0]["name"].ToString();
                    string subject_name = data.Rows[0]["subject_name"].ToString();
                    string subject_code = data.Rows[0]["subject_code"].ToString();
                    string email = data.Rows[0]["email"].ToString();
                    string username = data.Rows[0]["username"].ToString();




                    Form1 form1 = new Form1(name, email, subject_code, subject_name, username);
                    form1.Show();
                    this.Hide();


                }
                else
                {
                    MessageBox.Show("invalid username or password");

                }




            }



        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {



        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        // Event handler for exit button click
        private void button2_Click_1(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            
            if (result == DialogResult.Yes)
            {
               
                this.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
        }
    }
}
