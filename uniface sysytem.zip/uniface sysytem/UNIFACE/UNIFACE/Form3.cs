﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace UNIFACE
{
    public partial class Form3 : Form
    {
        // Constructor to initialize the Form3 instance
        // Variables to store user information
        private string name;
        private string subject_name;
        private string subject_code;
        private string email;
        private string username;
        // Constructor to initialize the form with user information
        public Form3(string name, string subject_name, string subject_code,string username,string email)
        {
            InitializeComponent();

            this.name = name;
            this.subject_name = subject_name;
            this.subject_code = subject_code;
            this.email = email;
            this.username = username;

            label10.Text = name;
            label16.Text = subject_code;
            label17.Text = subject_name;
            label15.Text = email;
            label18.Text = username;
        }

        
        public Form3()
        {
          
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        // Event handler for logout label click
        private void label9_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Form2 form2 = new Form2();
                form2.Show();
                this.Hide();
            }
            
        }


        // Event handler for exit icon click
        private void pictureBox11_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Form2 form2 = new Form2();
                form2.Show();
                this.Hide();
            }


        }

        // Event handler for label click to open Form1
        private void label4_Click(object sender, EventArgs e)
        {
            try
            {
                // Pass the user information to the Form1 constructor
                Form1 form1 = new Form1(name, email, subject_code, subject_name, username); // Replace with actual user information
                form1.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }
    }
}
