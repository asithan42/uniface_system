﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UNIFACE
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Retrieve values from textboxes
            string value1 = textBox1.Text;
            string value2 = textBox2.Text;
            string value3 = textBox3.Text;
            string value4 = textBox4.Text;
            string value5 = textBox5.Text;
            string value6 = textBox6.Text;

            // Check if any of the textboxes are empty
            if (string.IsNullOrWhiteSpace(value1) || string.IsNullOrWhiteSpace(value2) || string.IsNullOrWhiteSpace(value3) ||
                string.IsNullOrWhiteSpace(value4) || string.IsNullOrWhiteSpace(value5) || string.IsNullOrWhiteSpace(value6))
            {
                MessageBox.Show("Please fill in all fields before adding a record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method without attempting to insert into the database
            }

            // Your connection string
            // string connectionString = @"Data Source=DESKTOP-M0HGLG4\SQLEXPRESS;Initial Catalog=uniface;Integrated Security=True";

            // Your SQL insert query
            string insertQuery = "INSERT INTO login (name, username, password, subject_name, subject_code, email) VALUES (@Value1, @Value2, @Value3, @Value4, @Value5, @Value6)";

            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-M0HGLG4\SQLEXPRESS;Initial Catalog=uniface;Integrated Security=True"))
            {
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Add parameters to prevent SQL injection
                    command.Parameters.AddWithValue("@Value1", value1);
                    command.Parameters.AddWithValue("@Value2", value2);
                    command.Parameters.AddWithValue("@Value3", value3);
                    command.Parameters.AddWithValue("@Value4", value4);
                    command.Parameters.AddWithValue("@Value5", value5);
                    command.Parameters.AddWithValue("@Value6", value6);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Record added successfully!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
    }
}
